# -*- coding: utf-8 -*-

{
    "name": "Real Estate Accounting",
    "depends": [
        "estate",
        "account",
    ],
    "auto_install": True,
}
